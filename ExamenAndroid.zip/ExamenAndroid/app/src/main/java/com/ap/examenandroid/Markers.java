package com.ap.examenandroid;

/**
 * Created by Mathias on 6-10-2017.
 */

public class Markers {
    private String latitude;
    private String longitude;
    private String beschrijving;

    public Markers(String latitude, String longitude, String beschrijving) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.beschrijving = beschrijving;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getBeschrijving() {
        return beschrijving;
    }

    public void setBeschrijving(String beschrijving) {
        this.beschrijving = beschrijving;
    }
}
